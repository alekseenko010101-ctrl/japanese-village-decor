# Japanese Village Decor

NeoForge mod for Minecraft Java Edition 1.21.1.

Adds:
- `japanese_village:japanese_bonsai` — decorative Japanese bonsai block.
- Creative tab: `Japanese Village Decor`.
- Crafting recipe:

```text
[empty]  [acacia/cherry sapling]  [empty]
[dirt]   [dirt]                  [dirt]
[wood]   [flower pot]            [wood]
```

Wood accepts vanilla logs and planks through the `japanese_village:bonsai_wood_blocks` item tag.

## Build on GitHub from phone

1. Create a new GitHub repository.
2. Upload all files from this folder.
3. Open the repository → Actions → `Build NeoForge Mod` → Run workflow.
4. Open the finished workflow → Artifacts → download `japanese-village-decor-jar`.
5. Put the `.jar` into the Minecraft `mods` folder together with matching NeoForge 1.21.1.

## Edit model

The editable Blockbench file is here:

```text
blockbench/japanese_bonsai.bbmodel
```

The in-game model file is here:

```text
src/main/resources/assets/japanese_village/models/block/japanese_bonsai.json
```
