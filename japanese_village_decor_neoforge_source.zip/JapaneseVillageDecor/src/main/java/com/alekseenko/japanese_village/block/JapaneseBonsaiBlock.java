package com.alekseenko.japanese_village.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class JapaneseBonsaiBlock extends Block {
    private static final VoxelShape SHAPE = Shapes.or(
            // Подставка + горшок. Крона визуально выше, но не мешает ходить рядом.
            Block.box(2.0D, 0.0D, 2.0D, 13.0D, 7.0D, 14.0D),
            Block.box(6.0D, 7.0D, 3.0D, 11.0D, 16.0D, 13.0D)
    );

    public JapaneseBonsaiBlock(Properties properties) {
        super(properties);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    public VoxelShape getOcclusionShape(BlockState state, BlockGetter level, BlockPos pos) {
        return Shapes.empty();
    }
}
