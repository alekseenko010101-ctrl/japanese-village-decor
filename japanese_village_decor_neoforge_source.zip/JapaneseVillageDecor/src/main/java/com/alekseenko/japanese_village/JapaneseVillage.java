package com.alekseenko.japanese_village;

import com.alekseenko.japanese_village.block.JapaneseBonsaiBlock;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(JapaneseVillage.MOD_ID)
public class JapaneseVillage {
    public static final String MOD_ID = "japanese_village";

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MOD_ID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MOD_ID);
    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);

    public static final DeferredBlock<JapaneseBonsaiBlock> JAPANESE_BONSAI = BLOCKS.register(
            "japanese_bonsai",
            () -> new JapaneseBonsaiBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.PLANT)
                    .strength(0.4F)
                    .sound(SoundType.WOOD)
                    .noOcclusion())
    );

    public static final DeferredItem<BlockItem> JAPANESE_BONSAI_ITEM = ITEMS.registerSimpleBlockItem("japanese_bonsai", JAPANESE_BONSAI);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> JAPANESE_VILLAGE_TAB = CREATIVE_MODE_TABS.register(
            "japanese_village_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.japanese_village"))
                    .withTabsBefore(CreativeModeTabs.BUILDING_BLOCKS)
                    .icon(() -> JAPANESE_BONSAI_ITEM.get().getDefaultInstance())
                    .displayItems((parameters, output) -> output.accept(JAPANESE_BONSAI_ITEM.get()))
                    .build()
    );

    public JapaneseVillage(IEventBus modEventBus) {
        BLOCKS.register(modEventBus);
        ITEMS.register(modEventBus);
        CREATIVE_MODE_TABS.register(modEventBus);
    }
}
